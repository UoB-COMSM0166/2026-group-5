// Tiled Map Renderer - Fix tile duplication/display errors/logic robustness issues
// Adapted for "basic test2" map, handles large GIDs and multi-layer rendering
class TiledMapRenderer {
    constructor(canvasId, mapName = "basic test2") { // Load new map by default
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.mapData = null;
        this.scale = 2; // Default 2x scale for better visibility
        this.showGrid = false;
        this.isReady = false;
        this.tilesetMap = new Map();
        this.mapName = mapName; // Accept map name for multi-map support
        // Centralized base tile size management (avoid scattered hardcoding)
        this.BASE_TILE_SIZE = 16;

        // Tileset configuration - Key: firstgid | Value: tileset info (Core: mapTileWidth/Height define actual pixel size on map)
        this.tilesetConfig = {
            // Basic tiles (1-10)
            1: { 
                name: 'floor', 
                image: './tilesets/floor128128.png',
                tileWidth: 128,
                tileHeight: 128,
                mapTileWidth: 128,
                mapTileHeight: 128,
                columns: 8,
                totalTiles: 64
            },
            2: {
                name: 'leftwall', 
                image: './tilesets/verticalwall_left3232.png',
                tileWidth: 32,
                tileHeight: 32,
                mapTileWidth: 32,
                mapTileHeight: 32,
                columns: 1,
                totalTiles: 1
            },
            3: {
                name: 'downwall', 
                image: './tilesets/verticalwall_horizontal3232.png',
                tileWidth: 32,
                tileHeight: 32,
                mapTileWidth: 32,
                mapTileHeight: 32,
                columns: 1,
                totalTiles: 1
            },
            4: { 
                name: 'rightwall', 
                image: './tilesets/verticalwall_right3232.png',
                tileWidth: 32,
                tileHeight: 32,
                mapTileWidth: 32,
                mapTileHeight: 32,
                columns: 1,
                totalTiles: 1
            },
            5: {
                name: 'facewall', 
                image: './tilesets/brick3232.jpg',
                tileWidth: 32,
                tileHeight: 32,
                mapTileWidth: 32,
                mapTileHeight: 32,
                columns: 1,
                totalTiles: 1
            },
            6: { 
                name: 'brownfloor', 
                image: './tilesets/floorbrown6464.png',
                tileWidth: 64,
                tileHeight: 64,
                mapTileWidth: 64,
                mapTileHeight: 64,
                columns: 1,
                totalTiles: 1
            },
            7: { 
                name: 'purplefloor', 
                image: './tilesets/floordarkpurple6464.png',  
                tileWidth: 64,
                tileHeight: 64,
                mapTileWidth: 64,
                mapTileHeight: 64,
                columns: 1,
                totalTiles: 1
            },
            8: { 
                name: 'table', 
                image: './tilesets/table6464.png',
                tileWidth: 64,
                tileHeight: 64,
                mapTileWidth: 64,
                mapTileHeight: 64,
                columns: 1,
                totalTiles: 1
            },
            9: {
                name: 'window', 
                image: './tilesets/window3232.png',
                tileWidth: 32,
                tileHeight: 32,
                mapTileWidth: 32,
                mapTileHeight: 32,
                columns: 1,
                totalTiles: 1
            },    
            10: {
                name: 'neonlight', 
                image: './tilesets/neonlight3232.png',
                tileWidth: 16,
                tileHeight: 16,
                mapTileWidth: 16,
                mapTileHeight: 16,
                columns: 2,     // 32px / 16px
                totalTiles: 4   // 2x2
            },
            14: { 
                name: 'cabinet', 
                image: './tilesets/cabinet3232.png',
                tileWidth: 32,
                tileHeight: 32,
                mapTileWidth: 32,
                mapTileHeight: 32,
                columns: 1,
                totalTiles: 1
            },    
            15: { 
                name: 'box', 
                image: './tilesets/chest_closed3232.png',
                tileWidth: 32,
                tileHeight: 32,
                mapTileWidth: 32,
                mapTileHeight: 32,
                columns: 1,
                totalTiles: 1
            },
            // 16: neonbars_yellow64
            16: {
                name: 'neonbars_yellow', 
                image: './tilesets/neonbars_yellow64.png',
                tileWidth: 16,
                tileHeight: 16,
                mapTileWidth: 16,
                mapTileHeight: 16,
                columns: 4,
                totalTiles: 8,
            },
            // 24: neonbars_multicolor64
            24: {
                name: 'neonbars_multicolor', 
                image: './tilesets/neonbars_multicolor64.png',
                tileWidth: 16,
                tileHeight: 16,
                mapTileWidth: 16,
                mapTileHeight: 16,
                columns: 4,
                totalTiles: 8,
            },
            // 32: neonbars_pink64 
            32: {
                name: 'neonbars_pink', 
                image: './tilesets/neonbars_pink64.png',
                tileWidth: 16,
                tileHeight: 16,
                mapTileWidth: 16,
                mapTileHeight: 16,
                columns: 4,
                totalTiles: 8,
            },
            // 40: neonbars_bluepink64
            40: {
                name: 'neonbars_bluepink', 
                image: './tilesets/neonbars_bluepink64.png',
                tileWidth: 16,
                tileHeight: 16,
                mapTileWidth: 16,
                mapTileHeight: 16,
                columns: 4,
                totalTiles: 8,
            },
            // 48: circuit64
            48: {
                name: 'circuit', 
                image: './tilesets/circuit64.png',
                tileWidth: 16,
                tileHeight: 16,
                mapTileWidth: 16,
                mapTileHeight: 16,
                columns: 4,
                totalTiles: 8,
            },
            // 56: pinksymbol
            56: {
                name: 'pinksymbol', 
                image: './tilesets/pinksymbol3232.png',
                tileWidth: 32,
                tileHeight: 32,
                mapTileWidth: 32,
                mapTileHeight: 32,
                columns: 1,
                totalTiles: 1
            },
            // 57: bluesymbol
            57: {
                name: 'bluesymbol', 
                image: './tilesets/bluesymbol3232.png',
                tileWidth: 32,
                tileHeight: 32,
                mapTileWidth: 32,
                mapTileHeight: 32,
                columns: 1,
                totalTiles: 1
            },
            // 58: 1616floortile (key?)
            58: {
                name: 'key', 
                image: './tilesets/key1616.png',  
                tileHeight: 16,
                mapTileWidth: 16,
                mapTileHeight: 16,
                columns: 1,
                totalTiles: 1
            }
        };
    }

    // Tiled flip flags (high bits)
    static FLIP_H = 0x80000000;
    static FLIP_V = 0x40000000;
    static FLIP_D = 0x20000000;
    static FLIP_MASK = TiledMapRenderer.FLIP_H | TiledMapRenderer.FLIP_V | TiledMapRenderer.FLIP_D;

    normalizeGid(gid) {
        // Convert e.g. 3221225479 -> real gid by stripping flip bits
        return (gid >>> 0) & ~TiledMapRenderer.FLIP_MASK;
    }

    // Initialize renderer
    async init() {
        try {
            if (typeof TileMaps === 'undefined' || !TileMaps[this.mapName]) {
                throw new Error(`Map data not found (TileMaps["${this.mapName}"] does not exist)`);
            }
            
            this.mapData = TileMaps[this.mapName];
            // Validate layer existence
            if (!this.mapData.layers || this.mapData.layers.length === 0) {
                throw new Error('No valid layers found in map');
            }
            console.log(`Map data loaded successfully: ${this.mapName}`, this.mapData);
            
            // Analyze GIDs used in map
            this.analyzeMap();
            // Update page info display
            this.updateInfo();
            // Resize canvas
            this.resizeCanvas();
            // Load all tilesets
            await this.loadAllTilesets();
            
            this.isReady = true;
            this.render();
            
        } catch (error) {
            console.error('Initialization failed:', error);
            this.showError(error.message);
        }
    }

    // Analyze GIDs used in each layer (filter invalid large GIDs)
    analyzeMap() {
        this.mapData.layers.forEach(layer => {
            if (layer.type === 'tilelayer') {
                const used = new Set(
                    layer.data
                        .map(g => this.normalizeGid(g))
                        .filter(g => g > 0)
                );
                console.log(`Layer "${layer.name}" used GIDs:`, Array.from(used).sort((a,b)=>a-b));
            }
        });
    }

    // Update map info on page (size/tile count/layer count)
    updateInfo() {
        const mapSize = document.getElementById('map-size');
        const tileSize = document.getElementById('tile-size');
        const layerCount = document.getElementById('layer-count');
        
        if (mapSize) mapSize.textContent = `${this.mapData.width} x ${this.mapData.height}`;
        if (tileSize) tileSize.textContent = `${this.mapData.tilewidth || this.BASE_TILE_SIZE} x ${this.mapData.tileheight || this.BASE_TILE_SIZE}`;
        if (layerCount) layerCount.textContent = this.mapData.layers.length;
    }

    // Resize canvas (based on map grid count * base grid size * scale)
    resizeCanvas() {
        const width = this.mapData.width * this.BASE_TILE_SIZE * this.scale;
        const height = this.mapData.height * this.BASE_TILE_SIZE * this.scale;
        
        this.canvas.width = Math.floor(width);
        this.canvas.height = Math.floor(height);
        this.canvas.style.width = Math.floor(width) + 'px';
        this.canvas.style.height = Math.floor(height) + 'px';
    }

    // Match tileset for GID (Optimization: traverse in descending order, prioritize larger firstgid)
    getTilesetForGid(gid) {
        const raw = this.normalizeGid(gid);
        if (raw <= 0) return null;
        
        let bestMatch = null;
        // Convert to array and sort by firstgid descending to avoid matching errors
        const sortedTilesets = Array.from(this.tilesetMap.entries()).sort((a, b) => b[0] - a[0]);
        for (const [firstgid, data] of sortedTilesets) {
            if (firstgid <= raw) {
                bestMatch = { firstgid, data };
                break; // First match is optimal after descending sort
            }
        }
        // Add log when no tileset matched
        if (!bestMatch) {
            console.warn(`No matching tileset for GID: ${gid}`);
        }
        return bestMatch;
    }

    // Load all tileset images
    async loadAllTilesets() {
        const results = await Promise.all(
            Object.entries(this.tilesetConfig).map(([firstgid, config]) => 
                this.loadTilesetImage(parseInt(firstgid), config)
            )
        );
        
        const failed = results.filter(r => !r.success);
        if (failed.length > 0) {
            console.warn('Failed to load tilesets:', failed.map(f => f.config.name));
        }
    }

    // Load single tileset image (generate placeholder on failure)
    loadTilesetImage(firstgid, config) {
        return new Promise((resolve) => {
            const img = new Image();
            
            img.onload = () => {
                // Auto derive layout from actual PNG dimensions
                const cols = Math.floor(img.width / config.tileWidth);
                const rows = Math.floor(img.height / config.tileHeight);

                if (cols <= 0 || rows <= 0) {
                    console.warn(`[${firstgid}] Invalid tileset dimensions for ${config.name}: ${img.width}x${img.height}`);
                } else {
                    // Override hardcoded values (prevents blank tiles when columns is wrong)
                    config.columns = cols;
                    config.totalTiles = cols * rows;
                }

                console.log(` [${firstgid}] Tileset loaded successfully: ${config.name} (${img.width}x${img.height}) cols=${config.columns} total=${config.totalTiles}`);

                this.tilesetMap.set(firstgid, {
                    image: img,
                    config: config,
                    firstgid: firstgid,
                    loaded: true
                });

                resolve({ success: true, firstgid });
            };
            
            img.onerror = () => {
                console.error(`[${firstgid}] Failed to load tileset: ${config.image}`);
                
                const placeholder = this.createPlaceholder(config, firstgid);
                
                this.tilesetMap.set(firstgid, {
                    image: placeholder,
                    config: config,
                    firstgid: firstgid,
                    loaded: false,
                    isPlaceholder: true
                });
                
                resolve({ success: false, firstgid, config });
            };
            
            img.src = config.image;
        });
    }

    // Generate placeholder for failed tileset loading (Enhancement: add tileset name display)
    createPlaceholder(config, firstgid) {
        const canvas = document.createElement('canvas');
        const w = config.tileWidth;
        const h = config.tileHeight;
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        
        // Generate different background hues based on firstgid
        const hue = (firstgid * 60) % 360;
        ctx.fillStyle = `hsl(${hue}, 70%, 50%)`;
        ctx.fillRect(0, 0, w, h);
        
        // White border
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 2;
        ctx.strokeRect(0, 0, w, h);
        
        // Draw tileset name
        ctx.fillStyle = '#fff';
        ctx.font = `bold ${Math.min(w,h)/4}px Arial`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'top';
        ctx.fillText(config.name, w/2, 10);
        
        // Draw firstgid
        ctx.font = `bold ${Math.min(w,h)/2}px Arial`;
        ctx.textBaseline = 'middle';
        ctx.fillText(firstgid, w/2, h/2);
        
        return canvas;
    }

    drawTile(gid, gridX, gridY) {
        if (gid === 0) return;

        const tilesetInfo = this.getTilesetForGid(gid);
        if (!tilesetInfo) {
            this.drawErrorTile(gridX, gridY, gid, 'No matching tileset');
            return;
        }

        const { firstgid, data } = tilesetInfo;
        const { image, config, isPlaceholder } = data;

        if (!image) {
            this.drawErrorTile(gridX, gridY, gid, 'Tile image not found');
            return;
        }

        const raw = this.normalizeGid(gid);
        const tileIndex = raw - firstgid;

        if (tileIndex < 0 || tileIndex >= config.totalTiles) {
            this.drawErrorTile(gridX, gridY, gid, 'Tile index out of bounds');
            return;
        }

        // Calculate crop position in tileset
        const srcCol = tileIndex % config.columns;
        const srcRow = Math.floor(tileIndex / config.columns);
        const srcX = srcCol * config.tileWidth;
        const srcY = srcRow * config.tileHeight;

        const pixelScale = this.scale;

        const mapTileW = config.mapTileWidth || config.tileWidth;
        const mapTileH = config.mapTileHeight || config.tileHeight;

        const destW = mapTileW * pixelScale;
        const destH = mapTileH * pixelScale;

        let destX = gridX * this.BASE_TILE_SIZE * pixelScale;
        let destY = gridY * this.BASE_TILE_SIZE * pixelScale;

        const extraH = mapTileH - this.BASE_TILE_SIZE;
        const extraW = mapTileW - this.BASE_TILE_SIZE;

        // Y: shift UP by the extra height so big tiles don't look 1 cell too low
        let drawX = destX;
        let drawY = destY - extraH * pixelScale;

        // Realign ONLY for large tiles (e.g. 128x128 or bigger)
        const baseTileSize = this.BASE_TILE_SIZE;

        // NOTE: mapTileW/H can be 16, 32, 64, 128...
        if (mapTileW >= 128 || mapTileH >= 128) {
            // Calculate starting position of the area containing current cell
            const cellsW = Math.max(1, Math.round(mapTileW / baseTileSize));
            const cellsH = Math.max(1, Math.round(mapTileH / baseTileSize));

            const blockX = Math.floor(gridX / cellsW) * cellsW;
            const blockY = Math.floor(gridY / cellsH) * cellsH;

            destX = blockX * baseTileSize * pixelScale;
            destY = blockY * baseTileSize * pixelScale;
        }

        try {
            this.ctx.drawImage(
                image,
                srcX, srcY, config.tileWidth, config.tileHeight,
                drawX, drawY, destW, destH
            );

            if (isPlaceholder) {
                this.ctx.fillStyle = 'rgba(255, 0, 0, 0.3)';
                this.ctx.fillRect(destX, destY, destW, destH);
            }
        } catch (e) {
            console.error('Failed to draw tile:', e);
            this.drawErrorTile(gridX, gridY, gid, 'Drawing error');
        }
    }

    // Draw error tile (red background + yellow border + GID)
    drawErrorTile(gridX, gridY, gid, reason) {
        const w = this.BASE_TILE_SIZE * this.scale;
        const h = this.BASE_TILE_SIZE * this.scale;
        const x = gridX * w;
        const y = gridY * h;
        
        this.ctx.fillStyle = '#ff0000';
        this.ctx.fillRect(x, y, w, h);
        this.ctx.strokeStyle = '#ffff00';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(x, y, w, h);
        
        this.ctx.fillStyle = '#ffffff';
        this.ctx.font = `bold ${Math.max(8, w/2)}px Arial`;
        this.ctx.textAlign = 'center';
        this.ctx.fillText(gid, x + w/2, y + h/2);
        console.warn(`Error tile [${gid}] @ (${gridX},${gridY}): ${reason}`);
    }

    // Main rendering logic
    render() {
        if (!this.isReady) return;

        // Clear canvas background
        this.ctx.fillStyle = '#0f0f1a';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Render all visible tile layers in order
        this.mapData.layers.forEach((layer, idx) => {
            if (!layer.visible || layer.type !== 'tilelayer') return;
            this.renderLayer(layer, idx);
        });

        // Draw grid if enabled
        if (this.showGrid) this.drawGrid();
    }

    // Render single layer
    renderLayer(layer, idx) {
        const { width, height, data, name } = layer;
        // Validate layer data existence
        if (!data) {
            console.warn(`Layer ${idx}: ${name} has no data, skipping rendering`);
            return;
        }
        
        let count = 0;
        // Traverse all grid cells in layer and draw tiles
        for (let gridY = 0; gridY < height; gridY++) {
            for (let gridX = 0; gridX < width; gridX++) {
                const index = gridY * width + gridX;
                const gid = data[index];
                if (gid === 0) continue;
                
                this.drawTile(gid, gridX, gridY);
                count++;
            }
        }
        console.log(`Layer ${idx}: ${name} rendered tile count: ${count}`);
    }

    // Draw grid (debug helper)
    drawGrid() {
        const tileSize = this.BASE_TILE_SIZE * this.scale;
        const width = this.mapData.width * tileSize;
        const height = this.mapData.height * tileSize;
        
        this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        this.ctx.lineWidth = 1;
        
        // Draw vertical lines
        for (let x = 0; x <= width; x += tileSize) {
            this.ctx.beginPath();
            this.ctx.moveTo(x, 0);
            this.ctx.lineTo(x, height);
            this.ctx.stroke();
        }
        
        // Draw horizontal lines
        for (let y = 0; y <= height; y += tileSize) {
            this.ctx.beginPath();
            this.ctx.moveTo(0, y);
            this.ctx.lineTo(width, y);
            this.ctx.stroke();
        }
    }

    // Show initialization error message
    showError(message) {
        const errorEl = document.getElementById('map-error');
        if (errorEl) {
            errorEl.textContent = `Initialization failed: ${message}`;
            errorEl.style.color = 'red';
            errorEl.style.padding = '10px';
        }
        // Draw error message on canvas
        this.ctx.fillStyle = '#ff0000';
        this.ctx.font = '20px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(message, this.canvas.width/2, this.canvas.height/2);
    }

    // Switch map (Extended feature: support dynamic map switching)
    async switchMap(newMapName) {
        this.mapName = newMapName;
        this.isReady = false;
        this.tilesetMap.clear();
        await this.init();
    }
}

// Initialization example (execute after page load)
window.addEventListener('load', () => {
    // Initialize renderer with canvas ID and map name
    const renderer = new TiledMapRenderer('map-canvas', 'basic test2');
    renderer.init();
/*
    // Optional: Bind grid display toggle button
    const gridToggle = document.getElementById('toggle-grid');
    if (gridToggle) {
        gridToggle.addEventListener('click', () => {
            renderer.showGrid = !renderer.showGrid;
            renderer.render();
        });
    }

    // Optional: Bind scale control
    const scaleControl = document.getElementById('scale-control');
    if (scaleControl) {
        scaleControl.addEventListener('input', (e) => {
            renderer.scale = parseFloat(e.target.value);
            renderer.resizeCanvas();
            renderer.render();
        });
    }
*/
});