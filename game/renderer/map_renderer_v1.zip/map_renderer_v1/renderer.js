// Tiled Map Renderer - Fix tile size mismatch issue
class TiledMapRenderer {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.mapData = null;
        this.scale = 2; // Default scale up by 2x for better visibility
        this.showGrid = false;
        this.isReady = false;
        this.tilesetMap = new Map();
        
        this.mapName = "basic test";
        
        // Tileset configuration - Key: Specify actual occupied size of each tile on the map
        this.tilesetConfig = {
            1: { 
                name: 'floor', 
                image: 'tilesets/128128floor.png',
                tileWidth: 128,       // Tile size in the image
                tileHeight: 128,
                mapTileWidth: 128,   // Grid size occupied on the map (pixels)
                mapTileHeight: 128,
                columns: 8,
                totalTiles: 64
            },
            2: { 
                name: 'linewall_left', 
                image: 'tilesets/3232verticalwall_left.png',
                tileWidth: 32,      // Image is 32x32
                tileHeight: 32,
                mapTileWidth: 32,   // Occupies 32x32 pixels on map (2x2 16px grids)
                mapTileHeight: 32,
                columns: 1,
                totalTiles: 1
            },
            3: { 
                name: 'linewall_down', 
                image: 'tilesets/3232verticalwall_down.png',
                tileWidth: 32,
                tileHeight: 32,
                mapTileWidth: 32,   // Occupies 2x2 grids
                mapTileHeight: 32,
                columns: 1,
                totalTiles: 1
            },
            4: { 
                name: 'linewall_right', 
                image: 'tilesets/3232verticalwall_right.png',
                tileWidth: 32,
                tileHeight: 32,
                mapTileWidth: 32,   // Occupies 2x2 grids
                mapTileHeight: 32,
                columns: 1,
                totalTiles: 1
            },
            5: { 
                name: 'FACEWALL', 
                image: 'tilesets/3232facewall.png',
                tileWidth: 32,
                tileHeight: 32,
                mapTileWidth: 32,
                mapTileHeight: 32,
                columns: 1,
                totalTiles: 1
            },

        };
    }

    async init() {
        try {
            if (typeof TileMaps === 'undefined' || !TileMaps[this.mapName]) {
                throw new Error('finding no map');
            }
            
            this.mapData = TileMaps[this.mapName];
            console.log('map data:', this.mapData);
            
            // Analyze tiles used by the map
            this.analyzeMap();
            
            this.updateInfo();
            this.resizeCanvas();
            
            await this.loadAllTilesets();
            
            this.isReady = true;
            this.render();
            
        } catch (error) {
            console.error('Initialization failed:', error);
            this.showError(error.message);
        }
    }

    analyzeMap() {
        // Count GIDs used by each layer
        this.mapData.layers.forEach(layer => {
            if (layer.type === 'tilelayer') {
                const used = new Set(layer.data.filter(g => g > 0));
                console.log(`Layer "${layer.name}" used GIDs:`, Array.from(used).sort((a,b)=>a-b));
            }
        });
    }

    updateInfo() {
        const mapSize = document.getElementById('map-size');
        const tileSize = document.getElementById('tile-size');
        const layerCount = document.getElementById('layer-count');
        
        if (mapSize) mapSize.textContent = `${this.mapData.width} x ${this.mapData.height}`;
        if (tileSize) tileSize.textContent = `${this.mapData.tilewidth} x ${this.mapData.tileheight}`;
        if (layerCount) layerCount.textContent = this.mapData.layers.length;
    }

    resizeCanvas() {
        // Canvas size based on map grid count * base grid size(16) * scale
        const baseTileSize = 16;
        const width = this.mapData.width * baseTileSize * this.scale;
        const height = this.mapData.height * baseTileSize * this.scale;
        
        this.canvas.width = Math.floor(width);
        this.canvas.height = Math.floor(height);
        this.canvas.style.width = Math.floor(width) + 'px';
        this.canvas.style.height = Math.floor(height) + 'px';
    }

    getTilesetForGid(gid) {
        if (gid <= 0) return null;
        
        let bestMatch = null;
        for (const [firstgid, data] of this.tilesetMap) {
            if (firstgid <= gid) {
                if (!bestMatch || firstgid > bestMatch.firstgid) {
                    bestMatch = { firstgid, data };
                }
            }
        }
        return bestMatch;
    }

    async loadAllTilesets() {
        const results = await Promise.all(
            Object.entries(this.tilesetConfig).map(([firstgid, config]) => 
                this.loadTilesetImage(parseInt(firstgid), config)
            )
        );
        
        const failed = results.filter(r => !r.success);
        if (failed.length > 0) {
            console.warn('Failed to load tilesets:', failed.map(f => f.config.name));
        }
    }

    loadTilesetImage(firstgid, config) {
        return new Promise((resolve) => {
            const img = new Image();
            
            img.onload = () => {
                console.log(` [${firstgid}] ${config.name}: ${img.width}x${img.height}`);
                
                this.tilesetMap.set(firstgid, {
                    image: img,
                    config: config,
                    firstgid: firstgid,
                    loaded: true
                });
                
                resolve({ success: true, firstgid });
            };
            
            img.onerror = () => {
                console.error(`[${firstgid}] Failed to load tilesets: ${config.image}`);
                
                const placeholder = this.createPlaceholder(config, firstgid);
                
                this.tilesetMap.set(firstgid, {
                    image: placeholder,
                    config: config,
                    firstgid: firstgid,
                    loaded: false,
                    isPlaceholder: true
                });
                
                resolve({ success: false, firstgid, config });
            };
            
            img.src = config.image;
        });
    }

    createPlaceholder(config, firstgid) {
        const canvas = document.createElement('canvas');
        const w = config.tileWidth;
        const h = config.tileHeight;
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        
        const hue = (firstgid * 60) % 360;
        ctx.fillStyle = `hsl(${hue}, 70%, 50%)`;
        ctx.fillRect(0, 0, w, h);
        
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 2;
        ctx.strokeRect(0, 0, w, h);
        
        ctx.fillStyle = '#fff';
        ctx.font = `bold ${Math.min(w,h)/2}px Arial`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(firstgid, w/2, h/2);
        
        return canvas;
    }

    drawTile(gid, gridX, gridY) {
    if (gid === 0) return;

    const tilesetInfo = this.getTilesetForGid(gid);
    if (!tilesetInfo) {
        this.drawErrorTile(gridX, gridY, gid, 'No tileset');
        return;
    }

    const { firstgid, data } = tilesetInfo;
    const { image, config, isPlaceholder } = data;
    
    if (!image) {
        this.drawErrorTile(gridX, gridY, gid, 'No image');
        return;
    }

    const tileIndex = gid - firstgid;
    if (tileIndex < 0 || tileIndex >= config.totalTiles) {
        this.drawErrorTile(gridX, gridY, gid, 'Index out of bounds');
        return;
    }
    
    // Crop position in tileset image
    const srcCol = tileIndex % config.columns;
    const srcRow = Math.floor(tileIndex / config.columns);
    const srcX = srcCol * config.tileWidth;
    const srcY = srcRow * config.tileHeight;
    
    // Base grid size
    const baseTileSize = 16;
    const pixelScale = this.scale;
    
    // Pixel size occupied by this tile on the map
    const mapTileW = config.mapTileWidth || config.tileWidth;
    const mapTileH = config.mapTileHeight || config.tileHeight;
    const destW = mapTileW * pixelScale;
    const destH = mapTileH * pixelScale;
    
    // Calculate drawing position
    let destX, destY;
    
    if (mapTileW === baseTileSize && mapTileH === baseTileSize) {
        // 16x16 tile: Align directly to grid
        destX = gridX * baseTileSize * pixelScale;
        destY = gridY * baseTileSize * pixelScale;
    } else {
        // 128x128 or larger tile: Align to top-left corner of grid area
        // Calculate starting position of area containing current grid
        const cellsW = mapTileW / baseTileSize; // Number of grids occupied horizontally (128/16=8)
        const cellsH = mapTileH / baseTileSize; // Number of grids occupied vertically (128/16=8)
        
        const blockX = Math.floor(gridX / cellsW) * cellsW;
        const blockY = Math.floor(gridY / cellsH) * cellsH;
        
        destX = blockX * baseTileSize * pixelScale;
        destY = blockY * baseTileSize * pixelScale;
    }

    try {
        this.ctx.drawImage(
            image,
            srcX, srcY, config.tileWidth, config.tileHeight,
            destX, destY, destW, destH
        );
        
        if (isPlaceholder) {
            this.ctx.fillStyle = 'rgba(255, 0, 0, 0.3)';
            this.ctx.fillRect(destX, destY, destW, destH);
        }
        
    } catch (e) {
        console.error('Drawing error:', e);
        this.drawErrorTile(gridX, gridY, gid, 'Drawing failed');
    }
}

    drawErrorTile(gridX, gridY, gid, reason) {
        const baseTileSize = 16;
        const w = baseTileSize * this.scale;
        const h = baseTileSize * this.scale;
        const x = gridX * w;
        const y = gridY * h;
        
        this.ctx.fillStyle = '#ff0000';
        this.ctx.fillRect(x, y, w, h);
        this.ctx.strokeStyle = '#ffff00';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(x, y, w, h);
        
        this.ctx.fillStyle = '#ffffff';
        this.ctx.font = `bold ${Math.max(8, w/2)}px Arial`;
        this.ctx.textAlign = 'center';
        this.ctx.fillText(gid, x + w/2, y + h/2);
    }

    render() {
        if (!this.isReady) return;

        // Clear background
        this.ctx.fillStyle = '#0f0f1a';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Render layers in order
        this.mapData.layers.forEach((layer, idx) => {
            if (!layer.visible || layer.type !== 'tilelayer') return;
            this.renderLayer(layer, idx);
        });

        if (this.showGrid) this.drawGrid();
    }

    renderLayer(layer, idx) {
        const { width, height, data, name } = layer;
        let count = 0;

        console.log(`Rendering layer ${idx}: ${name}, size ${width}x${height}`);

        for (let y = 0; y < height; y++) {
            for (let x = 0; x < width; x++) {
                const index = y * width + x;
                let gid = data[index];
                if (gid === 0) continue;
                
                // Clear flip flags
                gid = gid & 0x0FFFFFFF;
                
                this.drawTile(gid, x, y);
                count++;
            }
        }
        
        console.log(`  -> Drawn ${count} tiels`);
    }

    drawGrid() {
        const baseTileSize = 16;
        const tw = baseTileSize * this.scale;
        const th = baseTileSize * this.scale;
        
        this.ctx.strokeStyle = 'rgba(100, 200, 255, 0.15)';
        this.ctx.lineWidth = 1;
        this.ctx.beginPath();
        
        for (let x = 0; x <= this.mapData.width; x++) {
            this.ctx.moveTo(x * tw, 0);
            this.ctx.lineTo(x * tw, this.canvas.height);
        }
        for (let y = 0; y <= this.mapData.height; y++) {
            this.ctx.moveTo(0, y * th);
            this.ctx.lineTo(this.canvas.width, y * th);
        }
        this.ctx.stroke();
    }

    setScale(s) {
        this.scale = Math.max(0.5, Math.min(8, s));
        this.resizeCanvas();
        this.render();
    }

    toggleGrid() {
        this.showGrid = !this.showGrid;
        this.render();
    }

    showError(msg) {
        const el = document.getElementById('debug-info');
        if (el) el.innerHTML = `<span style="color: #ff6b6b">${msg}</span>`;
    }
}

let renderer;

window.onload = async () => {
    renderer = new TiledMapRenderer('mapCanvas');
    await renderer.init();
};

function zoomIn() { if (renderer) renderer.setScale(renderer.scale + 0.5); }
function zoomOut() { if (renderer) renderer.setScale(renderer.scale - 0.5); }
function resetView() { if (renderer) { renderer.setScale(2); renderer.showGrid = false; renderer.render(); } }
function toggleGrid() { if (renderer) renderer.toggleGrid(); }