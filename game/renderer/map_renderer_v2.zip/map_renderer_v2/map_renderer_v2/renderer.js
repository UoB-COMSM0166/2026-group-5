/* renderer.js
   Tiled TMJ + external TSX tilesets renderer using p5.js (no eval).
   - Supports tilesets with larger tile sizes (32/64 etc) by bottom-aligning tiles.
   - Supports Tiled flip flags (H/V/D).
   - Adds simple zoom/pan + optional grid.
*/

// ---- CONFIG ----
const MAP_URL = "basic_test2.tmj"; // change if your map file name differs

// ---- Tiled GID flip flags (highest bits) ----
const FLIP_H = 0x80000000;
const FLIP_V = 0x40000000;
const FLIP_D = 0x20000000;
const CLEAR_FLAGS = ~(FLIP_H | FLIP_V | FLIP_D);

// ---- State ----
let mapData = null;
let tilesets = [];    // loaded TSX tilesets with images
let gidRanges = [];   // tilesets with {firstgid,lastgid,...}

let zoom = 1;
let offsetX = 0;
let offsetY = 0;
let showGrid = false;

// Optional: drag-to-pan
let isDragging = false;
let lastMouseX = 0;
let lastMouseY = 0;

// ---- p5 preload ----
function preload() {
  // loadJSON is fine on Live Server; make sure file is in same folder
  mapData = loadJSON(MAP_URL);
}

// ---- p5 setup ----
async function setup() {
  console.log("setup start");

  // Create canvas to match full map size (in pixels)
  const w = mapData.width * mapData.tilewidth;
  const h = mapData.height * mapData.tileheight;

  const c = createCanvas(w, h);
  noSmooth();

  // If you have <div id="game-container">, attach the canvas there
  const container = document.getElementById("game-container");
  if (container) c.parent(container);

  // If you have CSS targeting #mapCanvas, set that id
  c.elt.id = "mapCanvas";

  showLoading(true);
  updateInfoUI();
  await loadAllTilesets(mapData);
  showLoading(false);

  // Build gid ranges (firstgid..lastgid) for quick lookup
  tilesets.sort((a, b) => a.firstgid - b.firstgid);
  gidRanges = [];
  for (let i = 0; i < tilesets.length; i++) {
    const a = tilesets[i];
    const b = tilesets[i + 1];
    a.lastgid = b ? b.firstgid - 1 : Number.POSITIVE_INFINITY;
    gidRanges.push(a);
  }

  console.log("tilesets loaded:", tilesets.length, tilesets);

  // Render once (we will redraw when controls change)
  noLoop();
  redraw();
}

// ---- p5 draw ----
function draw() {
  background(10);

  push();
  // Apply pan + zoom
  translate(offsetX, offsetY);
  scale(zoom);

  // Draw tile layers in map order
  for (const layer of mapData.layers) {
    if (layer.type !== "tilelayer") continue;
    if (layer.visible === false) continue;

    // Respect opacity if present (optional)
    const alpha = layer.opacity != null ? layer.opacity : 1;
    push();
    tint(255, 255 * alpha);

    drawTileLayer(layer);

    pop();
  }

  // Optional grid overlay
  if (showGrid) drawGrid();

  pop();
}

// ---- Draw one tile layer ----
function drawTileLayer(layer) {
  const mw = mapData.width;
  const mh = mapData.height;
  const tw = mapData.tilewidth;
  const th = mapData.tileheight;

  const data = layer.data; // already an array of gids

  for (let row = 0; row < mh; row++) {
    for (let col = 0; col < mw; col++) {
      const idx = row * mw + col;
      const raw = data[idx] >>> 0; // unsigned
      if (raw === 0) continue;

      const flipH = (raw & FLIP_H) !== 0;
      const flipV = (raw & FLIP_V) !== 0;
      const flipD = (raw & FLIP_D) !== 0;

      const gid = (raw & CLEAR_FLAGS) >>> 0;
      const ts = findTilesetForGid(gid);
      if (!ts) continue;

      const localId = gid - ts.firstgid;
      const cols = ts.columns || 1;

      const sx =
        (ts.margin || 0) + (localId % cols) * (ts.tilewidth + (ts.spacing || 0));
      const sy =
        (ts.margin || 0) +
        Math.floor(localId / cols) * (ts.tileheight + (ts.spacing || 0));

      // Base destination = top-left of the cell in map grid
      let dx = col * tw;
      let dy = row * th;

      // Bottom-align bigger tiles: shift up by (tilesetTileH - mapTileH)
      // This is the key fix so 32x32 / 64x64 tiles appear fully.
      dy -= (ts.tileheight - th);

      // Apply tileset tileoffset if present (Tiled supports this)
      dx += ts.tileoffsetx || 0;
      dy += ts.tileoffsety || 0;

      // Draw with flip transforms
      drawTileImage(ts.image, sx, sy, ts.tilewidth, ts.tileheight, dx, dy, flipH, flipV, flipD);
    }
  }
}

// ---- Find the tileset that owns a gid ----
function findTilesetForGid(gid) {
  // gidRanges is sorted by firstgid, each has lastgid
  // Simple linear is OK for small lists, but we can do binary if you want later
  for (const ts of gidRanges) {
    if (gid >= ts.firstgid && gid <= ts.lastgid) return ts;
  }
  return null;
}

// ---- Draw a single tile (supports H/V/D flip flags) ----
function drawTileImage(img, sx, sy, sw, sh, dx, dy, flipH, flipV, flipD) {
  // Tiled "diagonal" flip is a rotate+flip combo.
  // This implementation matches common Tiled renderers.
  push();

  // Move origin to destination, then apply transform, then draw at (0,0)
  translate(dx, dy);

  if (!flipD) {
    // Standard H/V flips
    scale(flipH ? -1 : 1, flipV ? -1 : 1);
    // If flipped, shift back because we're drawing from 0,0
    image(img, flipH ? -sw : 0, flipV ? -sh : 0, sw, sh, sx, sy, sw, sh);
  } else {
    // Diagonal flip:
    // Equivalent to: transpose + optional flips.
    // We'll rotate 90deg and then apply flips to match Tiled behavior.
    // This is a common approach used in many renderers.
    rotate(HALF_PI);
    // After rotation, axes swapped. Adjust flips accordingly.
    // Empirically consistent mapping:
    scale(flipV ? -1 : 1, flipH ? -1 : 1);
    image(img, 0, flipV ? -sw : 0, sh, sw, sx, sy, sw, sh);
  }

  pop();
}

// ---- Load all TSX tilesets referenced by the TMJ ----
async function loadAllTilesets(mapJson) {
  tilesets = [];

  for (const tsRef of mapJson.tilesets) {
    const firstgid = tsRef.firstgid;
    const tsxPath = tsRef.source; // e.g. "Tiled map/floor.tsx"

    const tsxText = await fetchText(tsxPath);
    const tsx = parseTSX(tsxText, tsxPath);

    // Load the image referenced by TSX
    const img = await loadImagePromise(tsx.imageSource);

    tilesets.push({
      firstgid,
      name: tsx.name,
      tilewidth: tsx.tilewidth,
      tileheight: tsx.tileheight,
      spacing: tsx.spacing,
      margin: tsx.margin,
      columns: tsx.columns,
      tilecount: tsx.tilecount,
      tileoffsetx: tsx.tileoffsetx,
      tileoffsety: tsx.tileoffsety,
      image: img,
      imageSource: tsx.imageSource,
      imagewidth: tsx.imagewidth,
      imageheight: tsx.imageheight,
    });
  }
}

// ---- Helpers: fetch text safely (handles spaces in file names) ----
async function fetchText(path) {
  // Encode spaces and other characters for URL
  const url = encodeURI(path);
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to fetch ${path}: ${res.status}`);
  return await res.text();
}

// ---- Helpers: parse TSX (XML) ----
function parseTSX(tsxText, tsxPathForDebug = "") {
  const parser = new DOMParser();
  const xml = parser.parseFromString(tsxText, "text/xml");

  const tilesetEl = xml.querySelector("tileset");
  if (!tilesetEl) throw new Error(`Invalid TSX (no <tileset>) in ${tsxPathForDebug}`);

  const imageEl = xml.querySelector("tileset > image");
  if (!imageEl) throw new Error(`Invalid TSX (no <image>) in ${tsxPathForDebug}`);

  const tileoffsetEl = xml.querySelector("tileset > tileoffset");

  const name = tilesetEl.getAttribute("name") || "";
  const tilewidth = parseInt(tilesetEl.getAttribute("tilewidth") || "0", 10);
  const tileheight = parseInt(tilesetEl.getAttribute("tileheight") || "0", 10);
  const spacing = parseInt(tilesetEl.getAttribute("spacing") || "0", 10);
  const margin = parseInt(tilesetEl.getAttribute("margin") || "0", 10);
  const columns = parseInt(tilesetEl.getAttribute("columns") || "1", 10);
  const tilecount = parseInt(tilesetEl.getAttribute("tilecount") || "0", 10);

  const imageSource = imageEl.getAttribute("source");
  const imagewidth = parseInt(imageEl.getAttribute("width") || "0", 10);
  const imageheight = parseInt(imageEl.getAttribute("height") || "0", 10);

  const tileoffsetx = tileoffsetEl ? parseInt(tileoffsetEl.getAttribute("x") || "0", 10) : 0;
  const tileoffsety = tileoffsetEl ? parseInt(tileoffsetEl.getAttribute("y") || "0", 10) : 0;

  // If the TSX image path is relative to the TSX file location,
  // and you keep same folder structure, fetch() should resolve it.
  // If not, you may need to prefix manually.
  return {
    name,
    tilewidth,
    tileheight,
    spacing,
    margin,
    columns,
    tilecount,
    imageSource,
    imagewidth,
    imageheight,
    tileoffsetx,
    tileoffsety,
  };
}

// ---- Helpers: p5 loadImage as Promise ----
function loadImagePromise(src) {
  return new Promise((resolve, reject) => {
    const url = encodeURI(src);
    loadImage(
      url,
      (img) => resolve(img),
      (err) => reject(new Error(`Failed to load image ${src}: ${err}`))
    );
  });
}

// ---- Grid drawing ----
function drawGrid() {
  const mw = mapData.width;
  const mh = mapData.height;
  const tw = mapData.tilewidth;
  const th = mapData.tileheight;

  stroke(255, 40);
  strokeWeight(1 / zoom); // keep thin when zooming
  noFill();

  for (let x = 0; x <= mw; x++) {
    line(x * tw, 0, x * tw, mh * th);
  }
  for (let y = 0; y <= mh; y++) {
    line(0, y * th, mw * tw, y * th);
  }
}

// ---- UI hooks (buttons in your HTML) ----
const ZOOM_LEVELS = [1, 2, 3, 4];
let zoomIndex = 0;

window.zoomIn = function () {
  zoomIndex = Math.min(zoomIndex + 1, ZOOM_LEVELS.length - 1);
  zoom = ZOOM_LEVELS[zoomIndex];
  redraw();
};

window.zoomOut = function () {
  zoomIndex = Math.max(zoomIndex - 1, 0);
  zoom = ZOOM_LEVELS[zoomIndex];
  redraw();
};

window.resetView = function () {
  zoom = 1;
  offsetX = 0;
  offsetY = 0;
  redraw();
};

window.toggleGrid = function () {
  showGrid = !showGrid;
  redraw();
};

// ---- Optional: mouse wheel zoom + drag pan ----
function mouseWheel(e) {
  // Zoom to mouse position (simple version)
  const factor = e.delta > 0 ? 0.9 : 1.1;
  const newZoom = constrain(zoom * factor, 0.25, 8);

  // Keep mouse point stable in world coordinates
  const mx = mouseX;
  const my = mouseY;

  const wx = (mx - offsetX) / zoom;
  const wy = (my - offsetY) / zoom;

  zoom = newZoom;

  offsetX = mx - wx * zoom;
  offsetY = my - wy * zoom;

  redraw();
  return false; // prevent page scroll
}

function mousePressed() {
  isDragging = true;
  lastMouseX = mouseX;
  lastMouseY = mouseY;
}

function mouseReleased() {
  isDragging = false;
}

function mouseDragged() {
  if (!isDragging) return;
  const dx = mouseX - lastMouseX;
  const dy = mouseY - lastMouseY;
  offsetX += dx;
  offsetY += dy;
  lastMouseX = mouseX;
  lastMouseY = mouseY;
  redraw();
}

// ---- Small UI helpers ----
function showLoading(on) {
  const el = document.getElementById("loading");
  if (!el) return;
  el.style.display = on ? "block" : "none";
}

function updateInfoUI() {
  const mapSize = document.getElementById("map-size");
  const tileSize = document.getElementById("tile-size");
  const layerCount = document.getElementById("layer-count");

  if (mapSize) mapSize.textContent = `${mapData.width} x ${mapData.height}`;
  if (tileSize) tileSize.textContent = `${mapData.tilewidth} x ${mapData.tileheight}`;
  if (layerCount) layerCount.textContent = `${mapData.layers.length}`;
}