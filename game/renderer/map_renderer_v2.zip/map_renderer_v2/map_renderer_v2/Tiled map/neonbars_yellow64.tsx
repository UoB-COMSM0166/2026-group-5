<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="neonbars_yellow64" tilewidth="16" tileheight="16" tilecount="6" columns="3">
 <image source="../../assets/images/adapted/decoratives/neonlights/neonbars_yellow64.png" width="55" height="32"/>
</tileset>
