<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="neonbars" tilewidth="64" tileheight="43" tilecount="1" columns="1">
 <image source="../../assets/images/adapted/decoratives/neonlights/neonbars64.png" width="64" height="43"/>
</tileset>
