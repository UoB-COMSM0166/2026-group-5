<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="circuit64" tilewidth="16" tileheight="16" tilecount="8" columns="4">
 <image source="../../assets/images/adapted/decoratives/neonlights/circuit64.png" width="64" height="33"/>
</tileset>
