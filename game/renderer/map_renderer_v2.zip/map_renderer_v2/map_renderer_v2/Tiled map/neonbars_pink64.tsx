<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="neonbars_pink64" tilewidth="16" tileheight="16" tilecount="2" columns="2">
 <image source="../../assets/images/adapted/decoratives/neonlights/neonbars_pink64.png" width="47" height="19"/>
</tileset>
