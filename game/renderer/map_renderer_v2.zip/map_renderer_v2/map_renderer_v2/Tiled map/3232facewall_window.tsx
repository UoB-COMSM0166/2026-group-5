<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="facewall_window" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <image source="../../assets/images/adapted/decoratives/window3232.png" width="33" height="32"/>
</tileset>
