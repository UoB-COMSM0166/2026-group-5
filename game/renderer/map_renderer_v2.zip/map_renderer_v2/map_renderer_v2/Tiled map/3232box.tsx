<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="3232box" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <image source="../../assets/images/adapted/interactives/chest_closed3232.png" width="32" height="32"/>
</tileset>
